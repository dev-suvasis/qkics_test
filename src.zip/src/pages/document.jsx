import { useEffect, useState } from "react";
import axiosSecure from "../components/utils/axiosSecure";
import { FaEye, FaFileAlt } from "react-icons/fa";
import DocumentDetailsModal from "../components/Documents/DocumentDetailsModal";

export default function DocumentList({ theme }) {
  const isDark = theme === "dark";
  const [documents, setDocuments] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null);

  const fetchDocuments = async () => {
    try {
      const res = await axiosSecure.get("/v1/documents/");
      setDocuments(res.data.results);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const text = isDark ? "text-white" : "text-black";

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {documents.map((doc) => (
          <div
            key={doc.uuid}
            className={`group relative p-8 premium-card transition-all duration-500 hover:shadow-2xl animate-fadeIn ${isDark ? "bg-neutral-900" : "bg-white"}`}
          >
            {/* Icon & Access Badge */}
            <div className="flex justify-between items-start mb-8">
              <div className="h-14 w-14 rounded-2xl bg-red-600/10 flex items-center justify-center text-red-500 shadow-inner group-hover:bg-red-600 group-hover:text-white transition-all duration-500">
                <FaFileAlt size={24} />
              </div>
              <span
                className={`text-[10px] uppercase font-black tracking-widest px-4 py-1.5 rounded-full border shadow-sm transition-all duration-500 ${doc.access_type === "PREMIUM"
                  ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                  : "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                  }`}
              >
                {doc.access_type}
              </span>
            </div>

            {/* Content */}
            <div className="mb-8">
              <h3 className={`font-black text-xl leading-tight mb-3 group-hover:text-red-500 transition-colors ${text}`}>
                {doc.title}
              </h3>
              <p className={`text-sm font-medium leading-relaxed opacity-50 line-clamp-3 ${text}`}>
                {doc.description}
              </p>
            </div>

            <div className={`w-full h-px mb-6 ${isDark ? "bg-white/5" : "bg-black/5"}`} />

            {/* Footer */}
            <div className="flex justify-between items-center">
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-widest opacity-30 mb-0.5">Updated</span>
                <span className={`text-[11px] font-bold ${text}`}>
                  {new Date(doc.updated_at || doc.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                </span>
              </div>
              <button
                onClick={() => setSelectedDoc(doc.uuid)}
                className={`flex items-center gap-3 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${isDark
                  ? "bg-white/5 text-white hover:bg-neutral-800"
                  : "bg-black/5 text-black hover:bg-neutral-900 hover:text-white"}`}
              >
                <FaEye size={14} />
                <span>Analyze</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedDoc && (
        <DocumentDetailsModal
          uuid={selectedDoc}
          theme={theme}
          onClose={() => setSelectedDoc(null)}
        />
      )}
    </div>
  );
}
